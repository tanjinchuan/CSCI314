class TourBooking{

  String tourID;
  String userID;
  String guideID;
  DateTime date;
  String bookingID;
  bool status;


  TourBooking({
    this.tourID,
    this.userID,
    this.guideID,
    this.date,
    this.status,
    this.bookingID,
});

}