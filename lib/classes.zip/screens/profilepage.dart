import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fluttertest/classes/tour.dart';
import 'package:fluttertest/util/state.dart';
import 'package:fluttertest/util/state_widget.dart';
import 'package:fluttertest/widgets/stardisplay.dart';
import 'loginpage.dart';


class ProfilePage extends StatefulWidget {
  final Tour tour;
  ProfilePage({Key key, this.tour}) : super(key: key);

  @override
  ProfilePageState createState() => ProfilePageState();
}

class ProfilePageState extends State<ProfilePage> {
    StateModel appState;

  String name;
  int ratings;
  int totalRaters;
  String rating;

  String description;
    final List<DropdownMenuItem> rate = [];


  @override
  void initState(){
    super.initState();

  }
  
  //update all
  void setRatingParameter() async{
    var doc = await Firestore.instance.collection('User').getDocuments();
    for (int i = 0; i < doc.documents.length; i++){
      await Firestore.instance.collection('User').document(doc.documents[i].documentID).updateData({
        'ratings': 5,
        'totalRaters': 1,
      });
    }
  }
  @override

  Widget build (BuildContext context){
          getProfile();

    appState = StateWidget.of(context).state;
    if ((appState.firebaseUserAuth == null || appState.user == null)) {
      return LoginPage();
    }
    return new Scaffold(
      appBar: new AppBar (
        centerTitle: true,
        title: new Text('Profile'),
        actions: <Widget>[
          new FlatButton(
            onPressed:(){
              saveReview(int.parse(rating));
              Navigator.pop(context);
            },
            child: new Text('Save'),
          )
        ],
      ),
      
      body: new Center(
        child: new Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            new Text(name),
            new StarDisplay(value: ratings),
            new DropdownButton(
              hint: new Text('Rate tour guide'),
              onChanged: (String item) {
                setState(() {
                  rating = item;
                });
              },
              value: rating,
              items: ['1', '2', '3', '4', '5'].map((String value) {
                return new DropdownMenuItem(
                  value: value,
                  child: new Text(value),
                );
              }).toList(),
            )
          ],
        )
      )
    );
  }


  void saveReview(int rate) async {
    
    double result = ratings + rate / (totalRaters+1);

    await Firestore.instance.collection('User').document(widget.tour.tourID).updateData({
      'ratings': result ,
      'totalRaters': totalRaters + 1,

    });
   
  
  }
  void getProfile() async {
    var doc = await Firestore.instance.collection('User').document(widget.tour.guideID).get();
    setState((){
      name = doc['displayName'];
      ratings = doc['ratings'];
      totalRaters = doc['totalRaters'];
    });
    


  }
}