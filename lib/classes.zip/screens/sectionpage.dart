import 'package:flutter/material.dart';
import 'package:fluttertest/screens/tourpage.dart';
import 'package:fluttertest/screens/hosttourpage.dart';

class SectionPage extends StatelessWidget {
  final String username;
  SectionPage({Key key, @required this.username}): super(key: key);
  
  @override
  Widget build (BuildContext context) {
    return new Container(
      color: Colors.white,
      child: new Column(
        children: <Widget> [
          new Padding(
            padding: EdgeInsets.all(30.0),
          ),
          new Container(
            height: 200.0,
            width: 300.0,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30.0),
              image: DecorationImage(
                image: AssetImage('assets/images/chuansplore.png'),
                fit: BoxFit.fitHeight,
              ),
            ),
            child: new FlatButton (
              child: Text("Book a tour", style: TextStyle(color: Colors.white,fontSize: 30.0,fontWeight: FontWeight.bold)),
              
              onPressed:() {
                Navigator.push(context, MaterialPageRoute(builder: (context) => TourPage()));
              }
            )
          ),

          new Padding(
            padding: EdgeInsets.all(30.0),
          ),
          //tourist

          
        ]
      )
    );
  }
}